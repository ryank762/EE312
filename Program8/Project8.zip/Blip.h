/* Project8 <Blip.h>
 * Ryan Kim
 * jk39938
 * EE312 Summer 2018
 * Slip days used: 0
 */

extern std::map<std::string, int> varTable;
extern std::map<std::string, int>::iterator varIt;

void Interpret();

int Evaluate();
